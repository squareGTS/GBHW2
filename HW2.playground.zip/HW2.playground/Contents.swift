import UIKit

//MARK - First Task
func parity(number: Int) {
    if number % 2 == 0 && number != 0 {
        print(number)
    }
}

parity(number: 2)

//MARK - Second Task
func devideByThree(number: Int) {
    if number % 3 == 0 && number != 0{
        print(number)
    }
}

devideByThree(number: 6)

//MARK - Third Task
var array: [Int] = []

func arrayFunc(number: Int) {
    var n = number
    for _ in 1...100 {
        n += 1
        array.append(n)
    }
    print(array)
}

arrayFunc(number: 0)

//MARK - Fourth Task
for n in array {
    if n % 2 == 0 {
        array.remove(at: array.firstIndex(of: n)!) // index of curent value
    }
}

for n in array {
    if n % 3 != 0 {
        array.remove(at: array.firstIndex(of: n)!)
    }
}
print(array)

//MARK - Five Task
    func fibonacci(n: Int) {
        var n1 = 0
        var n2 = 1
        
        if n == 0 {
            print("Invalid")
        } else if n == 1 {
            print(n1)
        } else if n == 2 {
            print(n1, n2)
        } else {
            var array = [n1, n2]
            for _ in 2..<n {
                let n3 = n1 + n2
                n1 = n2
                n2 = n3
                array.append(n3)
            }
            print(array)
        }
    }

fibonacci(n: 50)
